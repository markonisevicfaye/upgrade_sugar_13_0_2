<?php
// created: 2023-08-24 16:45:32
$manifest = array(
    'acceptable_sugar_flavors' => array('ENT'),
    'acceptable_sugar_versions' =>
        array(
            'exact_matches' => array('13.0.0.0','13.0.1.0'),
            'regex_matches' => array()
        ),
    'author' => 'SugarCRM, Inc.',
    'copy_files' =>
        array(
            'from_dir' => 'SugarEnt-Upgrade-13.0.x-to-13.0.2',
            'to_dir' => '',
            'force_copy' => array()
        ),
    'description' => '',
    'icon' => '',
    'is_uninstallable' => false,
    'offline_client_applicable' => true,
    'name' => 'SugarEnt',
    'published_date' => '2023-08-24 16:45:32',
    'type' => 'patch',
    'version' => '13.0.2',
    'flavor' => 'ENT',
);
